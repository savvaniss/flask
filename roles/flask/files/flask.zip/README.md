Simple Flask application that outputs hostname and server hits.

Endpoints:
  - /add_user : Adds a user to a mysql database based on the current user and host the application is running.
  - /users : List all users from database.
